package com.app.weatherapp.Adapter.DailyWeather;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.weatherapp.DailyForecastScreen;
import com.app.weatherapp.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DailyAdapter extends RecyclerView.Adapter<DailyAdapter.MyViewHolder> {

    public final List<DailyWeather> dailyWeather;
    public final DailyForecastScreen mainAct;

    public DailyAdapter(List<DailyWeather> dailyWeathers, DailyForecastScreen ma) {
        this.dailyWeather = dailyWeathers;
        mainAct = ma;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weather_row, parent, false);


        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        DailyWeather daily = dailyWeather.get(position);

        holder.txtDate.setText(daily.date);
        holder.txtHighLow.setText(daily.temp);
        holder.txtUvindex.setText("UV Index : "+daily.uvindex);
        holder.txtDescription.setText(daily.description);
        holder.txtProbabilityofPrecipitation.setText("( "+daily.precipitation+" )");
        holder.txtMorning.setText(String.format("%.0f° " + (daily.farenheit ? "F" : "C"), Double.parseDouble(daily.getMorning())));
        holder.txtAfternoon.setText(String.format("%.0f° " + (daily.farenheit ? "F" : "C"), Double.parseDouble(daily.getDay())));
        holder.txtEvening.setText(String.format("%.0f° " + (daily.farenheit ? "F" : "C"), Double.parseDouble(daily.getEvening())));
        holder.txtNight.setText(String.format("%.0f° " + (daily.farenheit ? "F" : "C"), Double.parseDouble(daily.getNight())));

        holder.txtDate.setText(daily.date);
        holder.imgWeatherIcon.setImageResource(mainAct.getResources().getIdentifier(daily.iconcode, "drawable", "com.app.weatherapp"));
    }

    @Override
    public int getItemCount() {
        return dailyWeather.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txtDate,txtHighLow,txtUvindex,txtDescription,txtProbabilityofPrecipitation,txtMorning,txtAfternoon,txtEvening,txtNight;
        ImageView imgWeatherIcon;

        MyViewHolder(View view) {
            super(view);
            txtDate = view.findViewById(R.id.txtDate);
            txtHighLow = view.findViewById(R.id.txtHighLow);
            txtUvindex = view.findViewById(R.id.txtUvindex);
            txtDescription = view.findViewById(R.id.txtDescription);
            txtProbabilityofPrecipitation = view.findViewById(R.id.txtProbabilityofPrecipitation);
            txtMorning = view.findViewById(R.id.txtMorning);
            txtAfternoon = view.findViewById(R.id.txtAfternoon);
            txtEvening = view.findViewById(R.id.txtEvening);
            txtNight = view.findViewById(R.id.txtNight);
            imgWeatherIcon = view.findViewById(R.id.imgWeatherIcon);
        }

    }
}