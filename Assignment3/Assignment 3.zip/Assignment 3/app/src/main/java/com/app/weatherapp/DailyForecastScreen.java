package com.app.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.app.weatherapp.Adapter.DailyWeather.DailyAdapter;
import com.app.weatherapp.Adapter.DailyWeather.DailyWeather;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class DailyForecastScreen extends AppCompatActivity {

    TextView txtLocation;
    RecyclerView dataView;
    String jsonData;
    boolean farenheit;
    ArrayList<DailyWeather> dailyWeathers = new ArrayList<DailyWeather>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_forecast_screen);
        viewInitlization();
        getData();
    }

    public void viewInitlization(){
        txtLocation = findViewById(R.id.txtLocation);
        dataView = findViewById(R.id.dataView);
    }

    public void getData(){
        jsonData = getIntent().getStringExtra("dailyData");
        farenheit = getIntent().getBooleanExtra("farenheit",true);
        txtLocation.setText(""+getIntent().getStringExtra("location"));

        try {
            JSONObject jObjMain = new JSONObject(jsonData);

            JSONArray daily = jObjMain.getJSONArray("daily");
            for(int i = 0 ; i<daily.length();i++){
                JSONObject dateObject = daily.getJSONObject(i);

                String iconCode = "_" + (dateObject.getJSONArray("weather").getJSONObject(0).getString("icon"));
                String description = (dateObject.getJSONArray("weather").getJSONObject(0).getString("description"));
                String precipitation = dateObject.getString("pop") + "% precip.";
                String uvi = dateObject.getString("uvi");
                String morning = dateObject.getJSONObject("temp").getString("morn");
                String afternoon = dateObject.getJSONObject("temp").getString("day");
                String evening = dateObject.getJSONObject("temp").getString("eve");
                String night = dateObject.getJSONObject("temp").getString("night");

                Calendar cal = Calendar.getInstance(Locale.ENGLISH);
                cal.setTimeInMillis(Long.parseLong(dateObject.getString("dt")) * 1000);
                String date = new SimpleDateFormat("EEEE, MM/dd").format(cal.getTime());

//               LocalDateTime ldt = LocalDateTime.ofEpochSecond(Long.parseLong(dateObject.getString("dt")) + Integer.parseInt(wObj.getString("timezone_offset")), 0, ZoneOffset.UTC);
                String highLowTemperature = String.format("%.0f° " + (farenheit ? "F" : "C"), Double.parseDouble(dateObject.getJSONObject("temp").getString("max"))) +" / " +String.format("%.0f° " + (farenheit ? "F" : "C"), Double.parseDouble(dateObject.getJSONObject("temp").getString("min")));


                dailyWeathers.add(new DailyWeather(
                        date,
                        highLowTemperature,
                        description,
                        precipitation,
                        uvi,
                        morning,
                        afternoon,
                        evening,
                        night,
                        iconCode,
                        farenheit
                ));

            }

            DailyAdapter dailyAdapter = new DailyAdapter(dailyWeathers,DailyForecastScreen.this);
            dataView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            dataView.setAdapter(dailyAdapter);

        } catch (Exception e) {
            Log.d("Error",""+e.getMessage());
        }
    }
}